// Portal NFT — сервер: отдаёт сайт и пересылает заказы в Telegram-бота.
// Запуск: node server.js  (нужен Node.js 18+)
const http=require('http'),fs=require('fs'),path=require('path');
const dir=__dirname;
try{fs.readFileSync(path.join(dir,'config.env'),'utf8').split(/\r?\n/).forEach(l=>{
  const m=l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
  if(m&&!(m[1] in process.env))process.env[m[1]]=m[2].replace(/^["']|["']$/g,'');
})}catch{}
const {BOT_TOKEN,CHAT_ID,PORT=8000}=process.env;
if(!BOT_TOKEN||!CHAT_ID)console.warn('⚠ Заполните BOT_TOKEN и CHAT_ID в файле config.env');

// список подарков берём из script.js — цену клиент подделать не сможет
const GIFTS=JSON.parse(fs.readFileSync(path.join(dir,'script.js'),'utf8').match(/const G=(\[[\s\S]*?\]),g=document/)[1]);
const M=['Неон','Призрак','Кристалл','Лава','Нефрит','Мираж','Космос','Эхо'];
const C=[['Оникс','#52525e'],['Рубин','#e11d48'],['Сапфир','#2563eb'],['Изумруд','#10b981'],['Аметист','#8b5cf6'],['Янтарь','#f59e0b'],['Аквамарин','#22d3ee'],['Роза','#ff4fd8']];
const pick=a=>a[Math.floor(Math.random()*a.length)];
const hits=new Map();
const limited=ip=>{const n=Date.now(),a=(hits.get(ip)||[]).filter(t=>n-t<60000);a.push(n);hits.set(ip,a);return a.length>5};
const TYPES={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.png':'image/png','.webp':'image/webp'};
const FILES=['index.html','style.css','script.js'];

http.createServer((req,res)=>{
  if(req.method==='POST'&&req.url==='/api/order'){
    let b='';
    req.on('data',c=>{b+=c;if(b.length>5000)req.destroy()});
    req.on('end',async()=>{
      const send=(c,o)=>{res.writeHead(c,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
      try{
        if(limited(req.socket.remoteAddress))return send(429,{error:'rate'});
        const d=JSON.parse(b),g=GIFTS.find(x=>x.n===d.gift);
        const nick=String(d.nick||'').replace(/^@/,''),email=String(d.email||'').trim();
        if(!g||!/^[A-Za-z0-9_]{5,32}$/.test(nick)||!/^[^\s@<>&"']+@[^\s@<>&"']+\.[^\s@<>&"']{2,}$/.test(email))return send(400,{error:'bad'});
        const c=pick(C),r={model:pick(M),color:c[0],hex:c[1],number:'#'+String(Math.floor(Math.random()*99999)+1).padStart(5,'0')};
        const id=Date.now().toString(36).toUpperCase().slice(-6);
        const text=`🛒 Новый заказ ${id}\n\nПодарок: ${g.n} (⭐ ${g.p}+)\nНик: @${nick}\nПочта: ${email}\n\n🎲 Рандомайзер\nМодель: ${r.model}\nЦвет: ${r.color}\nНомер: ${r.number}`;
        const tg=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chat_id:CHAT_ID,text})});
        if(!tg.ok){console.error('Telegram:',await tg.text());return send(502,{error:'tg'})}
        send(200,r);
      }catch(e){console.error(e);send(500,{error:'err'})}
    });
    return;
  }
  let p=decodeURIComponent(req.url.split('?')[0]);if(p==='/')p='/index.html';
  const f=path.join(dir,p),rel=path.relative(dir,f).split(path.sep).join('/');
  if(!(FILES.includes(rel)||rel.startsWith('images/'))){res.writeHead(404);return res.end('404')}
  fs.readFile(f,(e,data)=>{
    if(e){res.writeHead(404);return res.end('404')}
    res.writeHead(200,{'Content-Type':TYPES[path.extname(f)]||'application/octet-stream'});res.end(data);
  });
}).listen(PORT,()=>console.log('Portal NFT: http://localhost:'+PORT));
