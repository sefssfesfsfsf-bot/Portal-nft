# Portal NFT

## Вариант 1. GitHub Pages + Cloudflare Worker (без сервера)
1. Загрузите содержимое этой папки в корень репозитория, Settings → Pages → Deploy from branch → main.
2. Cloudflare → Workers & Pages → Create → Hello World → Edit code → вставьте `worker.js` → Deploy.
3. Worker → Settings → Variables and Secrets: `BOT_TOKEN` (тип Secret), `CHAT_ID`, по желанию `ALLOWED_ORIGIN` = https://ВАШ-НИК.github.io
4. Адрес воркера впишите в `config.js` (`window.API_URL`) и закоммитьте.

## Вариант 2. Свой сервер
`config.example.env` → `config.env`, затем `node server.js` (Node.js 18+).

Токен бота нельзя хранить в репозитории.
