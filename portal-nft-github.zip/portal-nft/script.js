const G=[
 {
  "n": "Пряничное сердце",
  "p": 481,
  "i": "images/gift-01.webp"
 },
 {
  "n": "Шутовской колпак",
  "p": 477,
  "i": "images/gift-02.webp"
 },
 {
  "n": "Пасхальная корзина",
  "p": 481,
  "i": "images/gift-03.webp"
 },
 {
  "n": "Букет с купюрами",
  "p": 481,
  "i": "images/gift-04.webp"
 },
 {
  "n": "Дымящаяся сигара",
  "p": 1303,
  "i": "images/gift-05.webp"
 },
 {
  "n": "Сердце на кнопке",
  "p": 549,
  "i": "images/gift-06.webp"
 },
 {
  "n": "Бенгальский огонь",
  "p": 481,
  "i": "images/gift-07.webp"
 },
 {
  "n": "Золотая медаль",
  "p": 460,
  "i": "images/gift-08.webp"
 },
 {
  "n": "Пионы",
  "p": 481,
  "i": "images/gift-09.webp"
 },
 {
  "n": "Деревянный свиток",
  "p": 481,
  "i": "images/gift-10.webp"
 },
 {
  "n": "Обезьянка с тарелками",
  "p": 687,
  "i": "images/gift-11.webp"
 },
 {
  "n": "Ракета",
  "p": 481,
  "i": "images/gift-12.webp"
 },
 {
  "n": "Весёлая какашка",
  "p": 481,
  "i": "images/gift-13.webp"
 },
 {
  "n": "Змейка 2025",
  "p": 400,
  "i": "images/gift-14.webp"
 },
 {
  "n": "Новогодний носок",
  "p": 445,
  "i": "images/gift-15.webp"
 },
 {
  "n": "Леденцовая трость",
  "p": 450,
  "i": "images/gift-16.webp"
 },
 {
  "n": "Подарок 2025",
  "p": 435,
  "i": "images/gift-17.webp"
 },
 {
  "n": "Золотой значок",
  "p": 481,
  "i": "images/gift-18.webp"
 },
 {
  "n": "Happy B-Day",
  "p": 481,
  "i": "images/gift-19.webp"
 },
 {
  "n": "Тёмные носки",
  "p": 470,
  "i": "images/gift-20.webp"
 },
 {
  "n": "Змейка в шапке",
  "p": 481,
  "i": "images/gift-21.webp"
 },
 {
  "n": "Вишнёвый торт",
  "p": 481,
  "i": "images/gift-22.webp"
 },
 {
  "n": "Световой меч",
  "p": 549,
  "i": "images/gift-23.webp"
 },
 {
  "n": "Лунная мечеть",
  "p": 481,
  "i": "images/gift-24.webp"
 },
 {
  "n": "Факел",
  "p": 481,
  "i": "images/gift-25.webp"
 },
 {
  "n": "Статуя Свободы",
  "p": 481,
  "i": "images/gift-26.webp"
 },
 {
  "n": "Хоккейная маска",
  "p": 857,
  "i": "images/gift-27.webp"
 },
 {
  "n": "Пёс-рэпер",
  "p": 481,
  "i": "images/gift-28.webp"
 },
 {
  "n": "Фонарь",
  "p": 481,
  "i": "images/gift-29.webp"
 },
 {
  "n": "Лапша",
  "p": 450,
  "i": "images/gift-30.webp"
 },
 {
  "n": "Радужный леденец",
  "p": 420,
  "i": "images/gift-31.webp"
 },
 {
  "n": "Эскимо",
  "p": 476,
  "i": "images/gift-32.webp"
 },
 {
  "n": "Фламинго-круг",
  "p": 479,
  "i": "images/gift-33.webp"
 },
 {
  "n": "Пакетик",
  "p": 481,
  "i": "images/gift-34.webp"
 },
 {
  "n": "Рюкзак Telegram",
  "p": 481,
  "i": "images/gift-35.webp"
 },
 {
  "n": "Торт 8",
  "p": 459,
  "i": "images/gift-36.webp"
 }
],g=document.getElementById('g'),t=document.getElementById('t');let f='all',s='';
const H=[['Ракета',24,14,52,34],['Золотая медаль',-2,54,34,20],['Статуя Свободы',66,52,34,26],['Фламинго-круг',68,6,30,16],['Световой меч',0,8,30,14]];
const p=document.getElementById('p');
H.forEach(([n,x,y,w,d])=>{const o=G.find(k=>k.n==n);if(!o)return;const e=document.createElement('div');e.className='fl';e.dataset.d=d;e.style.cssText=`left:${x}%;top:${y}%;width:${w}%`;e.innerHTML=`<img src="${o.i}" alt="${n}">`;p.appendChild(e)});
document.querySelector('.hero').addEventListener('pointermove',e=>{const r=p.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;p.querySelectorAll('.fl').forEach(o=>o.style.transform=`translate(${x*o.dataset.d}px,${y*o.dataset.d}px)`)});
function R(){let a=G.filter(k=>f=='all'||(f=='lo'&&k.p<460)||(f=='mid'&&k.p>=460&&k.p<=500)||(f=='hi'&&k.p>500));if(s=='up')a=[...a].sort((x,y)=>x.p-y.p);if(s=='dn')a=[...a].sort((x,y)=>y.p-x.p);g.innerHTML=a.map((k,i)=>`<div class="c" style="animation-delay:${i*45}ms"><img src="${k.i}" alt="${k.n}" style="animation-delay:-${i%5}s"><b>${k.n}</b><span class="pr">⭐ ${k.p.toLocaleString('ru')}+</span><button class="btn" data-n="${k.n}">Купить</button></div>`).join('')}
document.getElementById('bar').onclick=e=>{const b=e.target.closest('button');if(!b)return;if(b.dataset.f){f=b.dataset.f;s=''}else s=b.dataset.s;document.querySelectorAll('#bar button').forEach(x=>x.classList.toggle('on',x==b||(s&&!x.dataset.s&&0)));R()};
g.addEventListener('pointermove',e=>{const c=e.target.closest('.c');if(!c||e.pointerType=='touch')return;const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;c.style.transform=`rotateY(${x*20}deg) rotateX(${-y*20}deg) scale(1.05)`});
g.addEventListener('pointerleave',e=>{if(e.target.classList&&e.target.classList.contains('c'))e.target.style.transform=''},true);
g.onclick=e=>{const b=e.target.closest('.btn');if(!b)return;OP(b.dataset.n)};
R();
const q=i=>document.getElementById(i),md=q('md'),bx=q('bx');
const M=['Неон','Призрак','Кристалл','Лава','Нефрит','Мираж','Космос','Эхо'],C=[['Оникс','#52525e'],['Рубин','#e11d48'],['Сапфир','#2563eb'],['Изумруд','#10b981'],['Аметист','#8b5cf6'],['Янтарь','#f59e0b'],['Аквамарин','#22d3ee'],['Роза','#ff4fd8']],rn=a=>a[Math.floor(Math.random()*a.length)],num=()=>'#'+String(Math.floor(Math.random()*99999)+1).padStart(5,'0');
function CL(){md.classList.remove('o')}md.onclick=e=>{if(e.target==md)CL()};
function OP(n){const o=G.find(k=>k.n==n);bx.innerHTML=`<button class="x" id="x">×</button><img src="${o.i}" alt=""><h3>${o.n}</h3><p style="text-align:center;color:var(--gold);font-weight:800;margin:4px 0 14px">⭐ ${o.p.toLocaleString('ru')}+</p><label>Ник в Telegram</label><input id="nk" placeholder="@username" autocomplete="off" autocapitalize="off"><div class="er" id="e1"></div><label>Почта</label><input id="em" type="email" placeholder="you@mail.com" autocomplete="off"><div class="er" id="e2"></div><p class="hint">Модель, цвет и номер подарка выбираются случайно.</p><button class="btn" id="ok" style="width:100%;padding:14px">Оформить заказ</button>`;md.classList.add('o');q('x').onclick=CL;
q('ok').onclick=()=>{const nk=q('nk').value.trim().replace(/^@/,''),em=q('em').value.trim();let bad=0;q('e1').textContent=/^[A-Za-z0-9_]{5,32}$/.test(nk)?'':(bad=1,'Введите ник Telegram: 5–32 символа, буквы, цифры, _');q('e2').textContent=/^[^\s@<>&"']+@[^\s@<>&"']+\.[^\s@<>&"']{2,}$/.test(em)?'':(bad=1,'Введите корректную почту');if(!bad)RL(o,nk,em)}}
function RL(o,nk,em){bx.innerHTML=`<button class="x" id="x">×</button><div class="gl" id="gl"><img src="${o.i}" alt=""></div><h3>${o.n}</h3><div class="rl"><div><small>Модель</small><b id="r1">…</b></div><div><small>Цвет</small><b id="r2">…</b></div><div><small>Номер</small><b id="r3">…</b></div></div><p class="hint" id="fm">Рандомайзер крутится…</p>`;q('x').onclick=CL;let k=0,res=null,err=0;
fetch((window.API_URL||'')+'/api/order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gift:o.n,nick:nk,email:em})}).then(r=>r.ok?r.json():Promise.reject()).then(d=>res=d).catch(()=>err=1);
const iv=setInterval(()=>{const c=rn(C);q('r1').textContent=rn(M);q('r2').textContent=c[0];q('r3').textContent=num();q('gl').style.setProperty('--c',c[1]);
if(++k>24&&(res||err)){clearInterval(iv);if(err){q('fm').textContent='Не удалось отправить заказ. Попробуйте ещё раз позже.';return}
q('r1').textContent=res.model;q('r2').textContent=res.color;q('r3').textContent=res.number;q('gl').style.setProperty('--c',res.hex);q('fm').textContent='Заказ принят! Подарок для @'+nk+'. Подтверждение придёт на '+em+'.'}},85)}
q('tr').innerHTML=[...G.slice(0,18),...G.slice(0,18)].map(k=>`<img src="${k.i}" alt="">`).join('');
const io=new IntersectionObserver(es=>es.forEach(x=>x.isIntersecting&&x.target.classList.add('v')),{threshold:.08});document.querySelectorAll('.sec').forEach(x=>io.observe(x));
const cv=q('st'),cx=cv.getContext('2d'),P=[];let W,Hh;function rs(){W=cv.width=innerWidth;Hh=cv.height=innerHeight}rs();addEventListener('resize',rs);
for(let i=0;i<80;i++)P.push({x:Math.random(),y:Math.random(),r:Math.random()*1.6+.3,v:Math.random()*4e-4+1e-4,c:['139,92,246','34,211,238','255,255,255'][i%3]});
(function a(){cx.clearRect(0,0,W,Hh);P.forEach(p=>{p.y-=p.v;if(p.y<0)p.y=1;cx.fillStyle=`rgba(${p.c},${.25+.5*Math.abs(Math.sin(p.y*20+p.x*9))})`;cx.beginPath();cx.arc(p.x*W,p.y*Hh,p.r,0,7);cx.fill()});requestAnimationFrame(a)})();
